// JavaScript source code
var x = 7;
var y = 5;
var z = x * y;

console.log(z)

var solution = document.querySelector("p");

solution.innerText = z;
