// JavaScript source code
console.log("Hello World");
const greeting = "Hello World";
console.log(greeting)