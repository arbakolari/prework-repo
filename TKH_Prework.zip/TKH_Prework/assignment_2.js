// JavaScript source code
console.log("Hello World");
yourName = prompt("What is your name?");
console.log("Hello " + yourName);