// JavaScript source code
var overUnderArray = [1, 45, 32, 21, 5, 17, 43, 93];
for (var i = 0; i < overUnderArray.length; i++) {
    if (overUnderArray[i] < 25) {
        console.log("under");
    }
    else {
        console.log("over");
}
}